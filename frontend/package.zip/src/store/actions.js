export const set_is_login = (payload) => ({
  type: "set_is_login",
  payload,
});
export const set_user_info = (payload) => ({
  type: "set_user_info",
  payload,
});
