export const SET_IS_LOGIN = "set_is_login";
export const SET_USER_INFO = "set_user_info";
