import react, { useState } from "react";

export default function CartView() {
  retrun(
    <div className="max-w-5xl mx-auto px-4 py-8 md:py-12">
      <h2 className="text-2xl md:text-3xl font-bold mb-8 flex items-center gap-2">
        <ShoppingCart /> Giỏ hàng của bạn
      </h2>
      {cart.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl shadow-sm">
          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500 mb-6">Giỏ hàng đang trống</p>
          <Button variant="primary" onClick={() => setView("home")}>
            Mua sắm ngay
          </Button>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            {cart.map((item) => (
              <div
                key={item.cartItemId}
                className="flex items-start sm:items-center gap-4 bg-white p-4 rounded-xl shadow-sm border border-gray-100 transition-all hover:shadow-md"
              >
                <img
                  src={
                    Array.isArray(item.images) ? item.images[0] : item.images
                  }
                  alt={item.name}
                  className="w-20 h-20 md:w-24 md:h-24 rounded-lg object-cover bg-gray-100"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-base md:text-lg truncate">
                    {item.name}
                  </h3>
                  <p className="text-blue-600 font-medium">
                    {item.price.toLocaleString("vi-VN")} đ
                  </p>

                  {/* Display Selected Variants */}
                  <div className="flex items-center gap-3 mt-2 text-sm text-gray-600">
                    <span className="bg-gray-100 px-2 py-1 rounded text-xs">
                      Size: <b className="text-gray-800">{item.selectedSize}</b>
                    </span>
                    <span className="bg-gray-100 px-2 py-1 rounded text-xs flex items-center gap-1">
                      Màu:
                      <span
                        className="w-3 h-3 rounded-full border border-gray-300 inline-block"
                        style={getColorStyle(item.selectedColor)}
                      ></span>
                      {item.selectedColor}
                    </span>
                    <span className="ml-auto">SL: {item.qty}</span>
                  </div>
                </div>
                <Button
                  variant="danger"
                  className="p-2 rounded-full flex-shrink-0 opacity-80 hover:opacity-100"
                  onClick={() => removeFromCart(item.cartItemId)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 h-fit sticky top-20">
            {/* Total Box */}
            <h3 className="text-xl font-bold mb-4">Tổng quan</h3>
            <div className="flex justify-between mb-2 text-gray-600">
              <span>Tạm tính:</span>
              <span>{totalPrice.toLocaleString("vi-VN")} đ</span>
            </div>
            <div className="flex justify-between mb-4 text-gray-600">
              <span>Phí vận chuyển:</span>
              <span>30.000 đ</span>
            </div>
            <div className="border-t pt-4 flex justify-between font-bold text-xl mb-6">
              <span>Tổng cộng:</span>
              <span className="text-blue-600">
                {(totalPrice + 30000).toLocaleString("vi-VN")} đ
              </span>
            </div>
            <Button
              variant="primary"
              className="w-full py-3"
              onClick={() => setView("pay")}
            >
              Tiến hành thanh toán
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
