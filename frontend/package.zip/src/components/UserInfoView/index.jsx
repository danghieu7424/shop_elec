import react, { useState } from "react";

export default function UserInfoView() {
      const userOrders = orders.filter(o => o.userId === user.id);
      return (
        <div className="max-w-2xl mx-auto px-4 py-12">
            <div className="bg-white p-8 rounded-2xl shadow-lg text-center">
                <img src={user.picture} className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-blue-100" />
                <h2 className="text-2xl font-bold">{user.name}</h2>
                <p className="text-gray-500">{user.email}</p>
                <div className="mt-8 grid grid-cols-3 gap-4 text-left">
                    <div className="bg-blue-50 p-4 rounded-xl"><div className="text-2xl font-bold text-blue-600">{user.orders || 0}</div><div className="text-sm text-gray-600">Đơn hàng</div></div>
                    <div className="bg-green-50 p-4 rounded-xl"><div className="text-2xl font-bold text-green-600">{(user.spent || 0).toLocaleString()}đ</div><div className="text-sm text-gray-600">Đã tiêu</div></div>
                </div>
                {userOrders.length > 0 && <div className="mt-8 text-left"><h3 className="font-bold mb-4">Lịch sử</h3>{userOrders.map(o => <div key={o.id} className="border p-3 rounded mb-2 flex justify-between"><span>{o.id}</span><span>{o.total.toLocaleString()}đ - {o.status}</span></div>)}</div>}
            </div>
        </div>
      );
  }