import react, {useState} from 'react'

export default function ProductDetailView() {
  const [activeImg, setActiveImg] = useState(selectedProduct.images[0]);
  const [chosenSize, setChosenSize] = useState(null);
  const [chosenColor, setChosenColor] = useState(null);

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 md:py-12">
      <Button
        variant="secondary"
        className="mb-6"
        onClick={() => setView("home")}
      >
        ← Quay lại
      </Button>
      <div className="grid md:grid-cols-2 gap-8 md:gap-12 bg-white p-4 md:p-8 rounded-2xl shadow-sm">
        {/* Left: Images Gallery */}
        <div className="space-y-4">
          <div className="rounded-2xl overflow-hidden bg-gray-100 aspect-square relative shadow-inner">
            <img
              src={activeImg}
              alt={selectedProduct.name}
              className="w-full h-full object-cover absolute inset-0 transition-opacity duration-300"
            />
          </div>
          {selectedProduct.images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {selectedProduct.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImg(img)}
                  className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 ${
                    activeImg === img
                      ? "border-blue-600"
                      : "border-transparent hover:border-gray-300"
                  }`}
                >
                  <img
                    src={img}
                    className="w-full h-full object-cover"
                    alt="thumbnail"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Info & Selectors */}
        <div className="flex flex-col">
          <div className="mb-4">
            <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
              {selectedProduct.category}
            </span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
            {selectedProduct.name}
          </h1>
          <div className="text-3xl font-bold text-blue-600 mb-6">
            {selectedProduct.price.toLocaleString("vi-VN")} đ
          </div>

          {/* Description */}
          <div className="prose prose-sm text-gray-600 mb-8 leading-relaxed">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              Mô tả sản phẩm
            </h3>
            <p>
              {selectedProduct.description ||
                "Chưa có mô tả chi tiết cho sản phẩm này."}
            </p>
          </div>

          {/* Colors */}
          <div className="mb-6">
            <div className="flex justify-between mb-2">
              <label className="font-medium text-gray-700">Màu sắc</label>
              {chosenColor && (
                <span className="text-sm text-blue-600 font-medium">
                  {chosenColor}
                </span>
              )}
            </div>
            <div className="flex gap-3 flex-wrap">
              {selectedProduct.colors?.map((c) => (
                <button
                  key={c}
                  onClick={() => setChosenColor(c)}
                  className={`w-10 h-10 rounded-full shadow-sm flex items-center justify-center transition-all ${
                    chosenColor === c
                      ? "ring-2 ring-offset-2 ring-blue-600 scale-110"
                      : "hover:scale-105"
                  }`}
                  style={getColorStyle(c)}
                  title={c}
                >
                  {chosenColor === c &&
                    (c === "White" || c === "Parchment" || c === "Yellow" ? (
                      <CheckCircle size={16} className="text-gray-800" />
                    ) : (
                      <CheckCircle size={16} className="text-white" />
                    ))}
                </button>
              ))}
            </div>
          </div>

          {/* Sizes */}
          <div className="mb-8">
            <div className="flex justify-between mb-2">
              <label className="font-medium text-gray-700">
                Kích thước (EU)
              </label>
              {chosenSize && (
                <span className="text-sm text-blue-600 font-medium">
                  Size {chosenSize}
                </span>
              )}
            </div>
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
              {selectedProduct.sizes?.map((size) => (
                <button
                  key={size}
                  onClick={() => setChosenSize(size)}
                  className={`py-2 rounded-lg border font-medium transition-all ${
                    chosenSize === size
                      ? "border-blue-600 bg-blue-50 text-blue-600 ring-1 ring-blue-600"
                      : "border-gray-200 hover:border-gray-400"
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-auto pt-6 border-t">
            <Button
              variant="primary"
              className="w-full py-4 text-lg shadow-lg shadow-blue-100"
              onClick={() =>
                addToCart(selectedProduct, chosenSize, chosenColor)
              }
            >
              <ShoppingCart className="mr-2" /> Thêm vào giỏ hàng
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
