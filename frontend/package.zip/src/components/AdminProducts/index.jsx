import react, { useState } from "react";

export default function AdminProducts() {
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);

  // Enhanced Form Data State
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    category: "",
    imagesStr: "", // Handle comma separated URLs string
    description: "",
    sizesStr: "", // Handle comma separated numbers
    colorsStr: "", // Handle comma separated strings
  });

  const resetForm = () => {
    setFormData({
      name: "",
      price: "",
      category: "",
      imagesStr: "",
      description: "",
      sizesStr: "",
      colorsStr: "",
    });
    setEditingId(null);
  };

  const handleAddNew = () => {
    resetForm();
    setShowModal(true);
  };

  const handleEdit = (product) => {
    setFormData({
      name: product.name,
      price: product.price,
      category: product.category,
      imagesStr: product.images.join("\n"), // Join for textarea
      description: product.description || "",
      sizesStr: product.sizes?.join(", ") || "",
      colorsStr: product.colors?.join(", ") || "",
    });
    setEditingId(product.id);
    setShowModal(true);
  };

  const handleDelete = (id) => {
    if (window.confirm("Bạn có chắc chắn muốn xóa sản phẩm này?")) {
      setProducts(products.filter((p) => p.id !== id));
    }
  };

  const handleSave = (e) => {
    e.preventDefault();

    // Parse strings back to arrays
    const imagesArray = formData.imagesStr
      .split("\n")
      .map((s) => s.trim())
      .filter((s) => s !== "");
    const sizesArray = formData.sizesStr
      .split(",")
      .map((s) => parseInt(s.trim()))
      .filter((n) => !isNaN(n));
    const colorsArray = formData.colorsStr
      .split(",")
      .map((s) => s.trim())
      .filter((s) => s !== "");

    const productPayload = {
      name: formData.name,
      price: Number(formData.price),
      category: formData.category,
      images:
        imagesArray.length > 0
          ? imagesArray
          : ["https://via.placeholder.com/400"],
      description: formData.description,
      sizes: sizesArray.length > 0 ? sizesArray : [39, 40, 41],
      colors: colorsArray.length > 0 ? colorsArray : ["White"],
    };

    if (editingId) {
      // Update
      setProducts(
        products.map((p) =>
          p.id === editingId ? { ...productPayload, id: editingId } : p
        )
      );
    } else {
      // Add new
      const newProduct = {
        ...productPayload,
        id: Date.now(),
      };
      setProducts([...products, newProduct]);
    }
    setShowModal(false);
    resetForm();
  };
  return (
    <AdminLayout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Quản lý sản phẩm</h2>
        <Button variant="primary" onClick={handleAddNew}>
          <Plus size={18} /> Thêm mới
        </Button>
      </div>
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="p-4 font-medium text-gray-500 w-16">ID</th>
                <th className="p-4 font-medium text-gray-500 w-20">Ảnh</th>
                <th className="p-4 font-medium text-gray-500">Tên</th>
                <th className="p-4 font-medium text-gray-500">Giá</th>
                <th className="p-4 font-medium text-gray-500 text-right">
                  Hành động
                </th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr
                  key={p.id}
                  className="border-b last:border-0 hover:bg-gray-50"
                >
                  <td className="p-4 text-gray-500">#{p.id}</td>
                  <td className="p-4">
                    <img
                      src={p.images[0]}
                      alt=""
                      className="w-10 h-10 rounded object-cover bg-gray-200"
                    />
                  </td>
                  <td
                    className="p-4 font-medium max-w-xs truncate"
                    title={p.name}
                  >
                    {p.name}
                  </td>
                  <td className="p-4 whitespace-nowrap">
                    {p.price.toLocaleString()} đ
                  </td>
                  <td className="p-4 flex gap-2 justify-end">
                    <button
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                      onClick={() => handleEdit(p)}
                    >
                      <Edit size={18} />
                    </button>
                    <button
                      className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                      onClick={() => handleDelete(p.id)}
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Add/Edit */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center p-6 border-b bg-white sticky top-0 z-10">
              <h3 className="text-xl font-bold">
                {editingId ? "Sửa sản phẩm" : "Thêm sản phẩm mới"}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Tên sản phẩm"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  required
                />
                <Input
                  label="Giá (VNĐ)"
                  type="number"
                  value={formData.price}
                  onChange={(e) =>
                    setFormData({ ...formData, price: e.target.value })
                  }
                  required
                />
              </div>

              <Input
                label="Danh mục"
                value={formData.category}
                onChange={(e) =>
                  setFormData({ ...formData, category: e.target.value })
                }
                placeholder="VD: Running, Lifestyle..."
                required
              />

              <Input
                label="Mô tả sản phẩm"
                type="textarea"
                value={formData.description}
                onChange={(e) =>
                  setFormData({ ...formData, description: e.target.value })
                }
                placeholder="Nhập mô tả chi tiết..."
                className="min-h-[120px]"
              />

              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="Sizes (cách nhau bởi dấu phẩy)"
                  value={formData.sizesStr}
                  onChange={(e) =>
                    setFormData({ ...formData, sizesStr: e.target.value })
                  }
                  placeholder="39, 40, 41, 42"
                />
                <Input
                  label="Màu sắc (cách nhau bởi dấu phẩy)"
                  value={formData.colorsStr}
                  onChange={(e) =>
                    setFormData({ ...formData, colorsStr: e.target.value })
                  }
                  placeholder="Red, Blue, Black, White"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Danh sách link ảnh (mỗi dòng 1 link)
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 min-h-[100px] font-mono text-sm"
                  value={formData.imagesStr}
                  onChange={(e) =>
                    setFormData({ ...formData, imagesStr: e.target.value })
                  }
                  placeholder="https://example.com/image1.jpg&#10;https://example.com/image2.jpg"
                  required
                ></textarea>
              </div>

              {/* Preview Images */}
              {formData.imagesStr && (
                <div className="mt-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Xem trước ảnh:
                  </label>
                  <div className="flex gap-2 overflow-x-auto pb-2">
                    {formData.imagesStr
                      .split("\n")
                      .map(
                        (url, idx) =>
                          url.trim() && (
                            <img
                              key={idx}
                              src={url}
                              alt="Preview"
                              className="w-16 h-16 object-cover rounded border bg-gray-50 flex-shrink-0"
                              onError={(e) => (e.target.style.display = "none")}
                            />
                          )
                      )}
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-4 border-t mt-6">
                <Button
                  type="button"
                  variant="secondary"
                  className="flex-1"
                  onClick={() => setShowModal(false)}
                >
                  Hủy
                </Button>
                <Button type="submit" variant="primary" className="flex-1">
                  <Save size={18} /> Lưu lại
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
