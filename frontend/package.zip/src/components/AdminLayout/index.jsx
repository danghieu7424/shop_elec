import react, { useState } from "react";

export default function AdminLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-gray-100">
      <div className="hidden md:block w-64 bg-gray-900 text-white flex-shrink-0">
        <div className="p-4 text-xl font-bold border-b border-gray-800">
          Admin Portal
        </div>
        <nav className="p-4 space-y-2">
          <div
            onClick={() => setView("admin-stats")}
            className={`flex items-center gap-3 p-3 rounded cursor-pointer ${
              view === "admin-stats" ? "bg-blue-600" : "hover:bg-gray-800"
            }`}
          >
            <BarChart2 size={20} /> Thống kê
          </div>
          <div
            onClick={() => setView("admin-products")}
            className={`flex items-center gap-3 p-3 rounded cursor-pointer ${
              view === "admin-products" ? "bg-blue-600" : "hover:bg-gray-800"
            }`}
          >
            <Package size={20} /> Sản phẩm
          </div>
          <div
            onClick={() => setView("admin-orders")}
            className={`flex items-center gap-3 p-3 rounded cursor-pointer ${
              view === "admin-orders" ? "bg-blue-600" : "hover:bg-gray-800"
            }`}
          >
            <CreditCard size={20} /> Đơn hàng
          </div>
          <div
            onClick={() => setView("admin-users")}
            className={`flex items-center gap-3 p-3 rounded cursor-pointer ${
              view === "admin-users" ? "bg-blue-600" : "hover:bg-gray-800"
            }`}
          >
            <Users size={20} /> Người dùng
          </div>
          <div
            onClick={() => setView("home")}
            className="flex items-center gap-3 p-3 rounded cursor-pointer hover:bg-red-900 text-red-300 mt-8"
          >
            <LogOut size={20} /> Thoát
          </div>
        </nav>
      </div>
      <div className="md:hidden flex-1 flex flex-col h-screen">
        <div className="bg-gray-900 text-white p-4 flex justify-between items-center">
          <span className="font-bold">Admin Portal</span>
          <button
            onClick={() => setView("home")}
            className="text-sm bg-red-600 px-3 py-1 rounded"
          >
            Thoát
          </button>
        </div>
        <div className="flex overflow-x-auto bg-gray-800 text-white whitespace-nowrap">
          <div onClick={() => setView("admin-stats")} className="p-3">
            Thống kê
          </div>
          <div onClick={() => setView("admin-products")} className="p-3">
            Sản phẩm
          </div>
          <div onClick={() => setView("admin-orders")} className="p-3">
            Đơn hàng
          </div>
        </div>
        <div className="flex-1 p-4 overflow-auto">{children}</div>
      </div>
      <div className="hidden md:block flex-1 p-8 overflow-auto">{children}</div>
    </div>
  );
}
