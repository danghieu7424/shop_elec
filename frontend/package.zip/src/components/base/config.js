// const API_BASE_URL = 'https://danghieu7424.helioho.st';
const API_BASE_URL = 'http://localhost:5000';

export default API_BASE_URL;