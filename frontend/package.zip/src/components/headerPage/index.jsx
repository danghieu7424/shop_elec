import React, { useEffect, useState, useRef } from "react";
import { Link, useHistory } from "react-router-dom";
import { useStore, actions } from "../../store";

import logoImg from "./assets/logo/logo.png";
import "./style.scss";

export default function Header() {
  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center cursor-pointer flex-shrink-0" onClick={() => setView('home')}>
            <span className="text-2xl font-bold text-blue-600">Sneaker<span className="text-gray-800">Store</span></span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Tìm giày..." 
                className="pl-10 pr-4 py-1 rounded-full bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-400 w-64 transition-all duration-300 focus:w-72"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="w-4 h-4 text-gray-500 absolute left-3 top-2" />
            </div>
            
            <div className="relative cursor-pointer group" onClick={() => setView('cart')}>
              <ShoppingCart className="w-6 h-6 text-gray-600 group-hover:text-blue-600 transition-colors" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-bounce">
                  {cart.length}
                </span>
              )}
            </div>

            {user ? (
              <div className="flex items-center gap-3">
                <img src={user.picture} alt="Avatar" className="w-8 h-8 rounded-full border border-gray-200" />
                <div className="flex flex-col text-xs">
                  <span className="font-bold truncate max-w-[100px]">{user.name}</span>
                  <span className="text-gray-500 cursor-pointer hover:text-blue-600" onClick={() => setView('user')}>Hồ sơ</span>
                </div>
                {user.role === 'admin' && (
                  <Button variant="outline" className="ml-2 py-1 px-2 text-xs h-8" onClick={() => setView('admin-stats')}>Admin</Button>
                )}
                <LogOut className="w-5 h-5 text-gray-500 cursor-pointer hover:text-red-500 ml-2 transition-colors" onClick={logout} />
              </div>
            ) : (
              <div className="flex gap-2">
                 <Button variant="primary" className="py-1 px-3 text-sm h-9" onClick={() => loginGoogle('user')}>Login</Button>
                 <Button variant="secondary" className="py-1 px-3 text-sm h-9" onClick={() => loginGoogle('admin')}>Admin</Button>
              </div>
            )}
          </div>
          
           {/* Mobile Menu Button */}
           <div className="flex items-center md:hidden gap-4">
            <div className="relative cursor-pointer" onClick={() => setView('cart')}>
              <ShoppingCart className="w-6 h-6 text-gray-600" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </div>
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 rounded-md text-gray-600 hover:text-blue-600">
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu Dropdown */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 shadow-lg absolute w-full left-0 z-40 px-4 pb-4 pt-2 space-y-4">
          {/* ... (Mobile menu content - similar to previous version) ... */}
           <div className="relative mt-2">
            <input 
              type="text" 
              placeholder="Tìm kiếm..." 
              className="pl-10 pr-4 py-2 rounded-lg bg-gray-50 border border-gray-200 w-full"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="w-4 h-4 text-gray-500 absolute left-3 top-3" />
          </div>
          <Button variant="secondary" className="w-full justify-start" onClick={() => { setView('home'); setIsMenuOpen(false); }}>
             <Home className="w-4 h-4" /> Trang chủ
          </Button>
        </div>
      )}
    </nav>
  );
}
