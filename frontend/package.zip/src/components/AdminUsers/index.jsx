import react, { useState } from "react";

export default function AdminUsers() {
  const toggleLock = (id) =>
    setAllUsers(
      allUsers.map((u) =>
        u.id === id
          ? { ...u, status: u.status === "active" ? "locked" : "active" }
          : u
      )
    );
  return (
    <AdminLayout>
      <h2 className="text-2xl font-bold mb-6">Người dùng</h2>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="p-4">User</th>
              <th className="p-4">Role</th>
              <th className="p-4">Status</th>
              <th className="p-4">Action</th>
            </tr>
          </thead>
          <tbody>
            {allUsers.map((u) => (
              <tr key={u.id} className="border-b">
                <td className="p-4 flex items-center gap-2">
                  <img src={u.picture} className="w-8 h-8 rounded-full" />
                  <div>
                    {u.name}
                    <div className="text-xs text-gray-500">{u.email}</div>
                  </div>
                </td>
                <td className="p-4 uppercase text-xs font-bold">{u.role}</td>
                <td className="p-4">
                  <StatusBadge status={u.status} />
                </td>
                <td className="p-4">
                  <button
                    onClick={() => toggleLock(u.id)}
                    className="text-blue-600"
                  >
                    {u.status === "active" ? (
                      <Lock size={18} />
                    ) : (
                      <Unlock size={18} />
                    )}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
