import react, { useState } from "react";

export default function PaymentView() {
    // ... (Same content as before)
    const [paymentMethod, setPaymentMethod] = useState('cod');
    const [customerInfo, setCustomerInfo] = useState({name: user?.name || '', phone: '', address: ''});
    const handleSubmit = (e) => { e.preventDefault(); if(!customerInfo.name || !customerInfo.phone || !customerInfo.address) { alert("Vui lòng điền đầy đủ!"); return; } handlePlaceOrder(paymentMethod, customerInfo); }
    return (
        <div className="max-w-3xl mx-auto px-4 py-8 md:py-12">
            <Button variant="secondary" className="mb-4" onClick={() => setView('cart')}>← Quay lại giỏ hàng</Button>
            <div className="bg-white p-6 md:p-8 rounded-2xl shadow-lg">
                <h2 className="text-2xl font-bold mb-6 flex items-center gap-2"><CreditCard /> Thanh toán</h2>
                <form className="space-y-6" onSubmit={handleSubmit}>
                    <div className="grid md:grid-cols-2 gap-6">
                        <Input label="Họ tên người nhận" value={customerInfo.name} onChange={e => setCustomerInfo({...customerInfo, name: e.target.value})} />
                        <Input label="Số điện thoại" value={customerInfo.phone} onChange={e => setCustomerInfo({...customerInfo, phone: e.target.value})} />
                    </div>
                    <Input label="Địa chỉ giao hàng" value={customerInfo.address} onChange={e => setCustomerInfo({...customerInfo, address: e.target.value})} />
                    <div className="border-t pt-6">
                        <h3 className="font-bold mb-4">Phương thức thanh toán</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className={`border p-4 rounded-lg flex items-center gap-3 cursor-pointer ${paymentMethod === 'cod' ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' : ''}`} onClick={() => setPaymentMethod('cod')}>
                                <Truck className="w-5 h-5 text-blue-600" /><span className="font-medium">COD</span>
                            </div>
                            <div className={`border p-4 rounded-lg flex items-center gap-3 cursor-pointer ${paymentMethod === 'bank' ? 'bg-blue-50 border-blue-500 ring-1 ring-blue-500' : ''}`} onClick={() => setPaymentMethod('bank')}>
                                <CreditCard className="w-5 h-5 text-blue-600" /><span>Chuyển khoản</span>
                            </div>
                        </div>
                        {paymentMethod === 'bank' && (<div className="mt-4 p-4 bg-gray-50 rounded border text-sm"><p>Ngân hàng: <b>MB Bank</b> - STK: <b>0000 1234 56789</b></p></div>)}
                    </div>
                    <Button type="submit" className="w-full py-3 mt-6">Xác nhận ({(totalPrice + 30000).toLocaleString()} đ)</Button>
                </form>
            </div>
        </div>
    );
  }