import react, { useState } from "react";

export default function AdminOrders() {
  const updateStatus = (id, st) =>
    setOrders(orders.map((o) => (o.id === id ? { ...o, status: st } : o)));
  const [selOrd, setSelOrd] = useState(null);
  return (
    <AdminLayout>
      <h2 className="text-2xl font-bold mb-6">Đơn hàng</h2>
      <div className="bg-white rounded shadow overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="p-4">Mã</th>
              <th className="p-4">Khách</th>
              <th className="p-4">Tổng</th>
              <th className="p-4">TT</th>
              <th className="p-4">Action</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id} className="border-b">
                <td className="p-4 font-bold">{o.id}</td>
                <td className="p-4">
                  <div>{o.userName}</div>
                  <div className="text-xs text-gray-500">{o.phone}</div>
                </td>
                <td className="p-4 font-bold text-blue-600">
                  {o.total.toLocaleString()}
                </td>
                <td className="p-4">
                  <StatusBadge status={o.status} />
                </td>
                <td className="p-4 flex gap-2">
                  <button
                    onClick={() => setSelOrd(o)}
                    className="p-2 bg-gray-100 rounded"
                  >
                    <Eye size={16} />
                  </button>
                  {o.status === "pending" && (
                    <Button
                      className="py-1 px-2 text-xs"
                      onClick={() => updateStatus(o.id, "shipping")}
                    >
                      Duyệt
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {selOrd && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-lg max-h-[80vh] overflow-auto p-6">
            <div className="flex justify-between mb-4">
              <h3 className="font-bold text-xl">Chi tiết {selOrd.id}</h3>
              <button onClick={() => setSelOrd(null)}>
                <X />
              </button>
            </div>
            <div className="space-y-4">
              <div className="bg-gray-50 p-3 rounded">
                <b>Khách:</b> {selOrd.userName} - {selOrd.phone}
                <br />
                <b>ĐC:</b> {selOrd.address}
              </div>
              <div>
                {selOrd.items.map((i, idx) => (
                  <div key={idx} className="flex gap-3 border-b py-2">
                    <img
                      src={Array.isArray(i.images) ? i.images[0] : i.images}
                      className="w-12 h-12 rounded bg-gray-200 object-cover"
                    />
                    <div className="flex-1 text-sm">
                      <div className="font-medium">{i.name}</div>
                      <div className="text-gray-500">
                        Sz: {i.selectedSize} | Màu: {i.selectedColor} | SL:{" "}
                        {i.qty}
                      </div>
                    </div>
                    <div className="font-bold">
                      {(i.price * i.qty).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between font-bold text-lg pt-2 border-t">
                <span>Tổng</span>
                <span>{selOrd.total.toLocaleString()} đ</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
