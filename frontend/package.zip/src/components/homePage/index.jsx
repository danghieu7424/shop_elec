import React, { useState, useEffect, useMemo } from 'react';
import { ShoppingCart, User, Search, Menu, X, LogOut, Home, CreditCard, Package, Settings, BarChart2, Plus, Trash2, Edit, CheckCircle, Truck, XCircle, Users, DollarSign, Lock, Unlock, QrCode, Save, Eye, Image as ImageIcon } from 'lucide-react';

// --- Mock Data ---
const MOCK_PRODUCTS = [
  { 
    id: 1, 
    name: 'Nike Air Force 1', 
    price: 2500000, 
    category: 'Lifestyle', 
    images: [
      'https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=600&q=80'
    ],
    description: 'Huyền thoại sống mãi với thời gian. Nike Air Force 1 mang lại phong cách cổ điển pha lẫn hiện đại. Đế Air êm ái giúp bạn thoải mái cả ngày dài. Chất liệu da cao cấp dễ dàng vệ sinh.',
    sizes: [38, 39, 40, 41, 42, 43],
    colors: ['White', 'Black']
  },
  { 
    id: 2, 
    name: 'Adidas Ultraboost', 
    price: 3200000, 
    category: 'Running', 
    images: [
      'https://images.unsplash.com/photo-1587563871167-1ee797455c32?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=600&q=80'
    ],
    description: 'Đôi giày chạy bộ hoàn hảo với công nghệ đệm Boost phản hồi năng lượng cực tốt. Thân giày Primeknit ôm sát bàn chân, thoáng khí tối đa.',
    sizes: [40, 41, 42, 44],
    colors: ['Grey', 'Blue', 'Black']
  },
  { 
    id: 3, 
    name: 'Jordan 1 High OG', 
    price: 4500000, 
    category: 'Basketball', 
    images: [
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=600&q=80',
      'https://images.unsplash.com/photo-1515955656352-a1fa3ffcd111?auto=format&fit=crop&w=600&q=80'
    ],
    description: 'Biểu tượng của văn hóa sát mặt đất. Thiết kế High-top bảo vệ cổ chân, phối màu OG cực chất dành cho các tín đồ thời trang đường phố.',
    sizes: [41, 42, 43],
    colors: ['Red', 'White']
  },
  { 
    id: 4, 
    name: 'Puma RS-X', 
    price: 1800000, 
    category: 'Lifestyle', 
    images: ['https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=600&q=80'],
    description: 'Phong cách Retro Future độc đáo. Đế giày chunky hầm hố nhưng cực kỳ nhẹ nhàng.',
    sizes: [39, 40, 41],
    colors: ['Multi']
  },
  { 
    id: 5, 
    name: 'New Balance 550', 
    price: 2800000, 
    category: 'Vintage', 
    images: ['https://images.unsplash.com/photo-1539185441755-769473a23570?auto=format&fit=crop&w=600&q=80'],
    description: 'Sự trở lại của dòng giày bóng rổ thập niên 80. Thiết kế đơn giản, tinh tế, dễ phối đồ.',
    sizes: [38, 39, 40, 41, 42],
    colors: ['White', 'Green']
  },
  { 
    id: 6, 
    name: 'Converse Chuck 70', 
    price: 1600000, 
    category: 'Classic', 
    images: ['https://images.unsplash.com/photo-1607522370275-f14206abe5d3?auto=format&fit=crop&w=600&q=80'],
    description: 'Phiên bản nâng cấp của dòng Classic với đế ngà vintage, vải canvas dày dặn hơn và đệm lót êm ái.',
    sizes: [36, 37, 38, 39, 40, 41, 42, 43],
    colors: ['Black', 'Yellow', 'Parchment']
  },
];

const INITIAL_USERS = [
  { id: 'USER_123', name: 'Nguyen Van A', email: 'nguyenvana@gmail.com', role: 'user', status: 'active', spent: 0, orders: 0, picture: 'https://ui-avatars.com/api/?name=Nguyen+Van+A&background=random' },
  { id: 'ADMIN_001', name: 'Admin User', email: 'admin@store.com', role: 'admin', status: 'active', spent: 0, orders: 0, picture: 'https://ui-avatars.com/api/?name=Admin&background=000&color=fff' },
];

// --- Helper Functions ---
const getColorStyle = (colorName) => {
  const map = {
    'White': '#ffffff', 'Black': '#000000', 'Red': '#ef4444', 'Blue': '#3b82f6',
    'Green': '#22c55e', 'Yellow': '#eab308', 'Grey': '#6b7280', 'Multi': 'linear-gradient(45deg, red, blue)',
    'Parchment': '#f3e5ab'
  };
  const bg = map[colorName] || '#cbd5e1'; // Default gray
  return { background: bg, border: colorName === 'White' ? '1px solid #e5e7eb' : 'none' };
};


// --- Main Application ---

export default function HomePage() {
  const [view, setView] = useState('home'); 
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState(MOCK_PRODUCTS);
  const [orders, setOrders] = useState([]); 
  const [allUsers, setAllUsers] = useState(INITIAL_USERS); 
  
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Simulated Login
  const loginGoogle = (role = 'user') => {
    const foundUser = allUsers.find(u => u.role === role && u.status === 'active') || allUsers[0];
    if (foundUser.status === 'locked') {
      alert("Tài khoản của bạn đã bị khóa!");
      return;
    }
    setUser(foundUser);
    setView('home');
    setIsMenuOpen(false);
  };

  const logout = () => {
    setUser(null);
    setView('home');
    setCart([]);
    setIsMenuOpen(false);
  };

  // Add to Cart with Variants
  const addToCart = (product, size, color) => {
    if (!size || !color) {
      alert("Vui lòng chọn Size và Màu sắc!");
      return;
    }

    setCart(prev => {
      // Create a unique key for the item variation
      const itemKey = `${product.id}-${size}-${color}`;
      const exist = prev.find(x => x.cartItemId === itemKey);
      
      if (exist) {
        return prev.map(x => x.cartItemId === itemKey ? { ...x, qty: x.qty + 1 } : x);
      }
      
      return [...prev, { 
        ...product, 
        cartItemId: itemKey, // Unique ID for cart operations
        selectedSize: size, 
        selectedColor: color, 
        qty: 1 
      }];
    });
    alert(`Đã thêm ${product.name} (Size: ${size}, Màu: ${color}) vào giỏ!`);
  };

  const removeFromCart = (cartItemId) => {
    setCart(prev => prev.filter(x => x.cartItemId !== cartItemId));
  };

  const totalPrice = cart.reduce((acc, item) => acc + item.price * item.qty, 0);

  const handlePlaceOrder = (paymentMethod, customerInfo) => {
    const newOrder = {
      id: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      userId: user?.id || 'GUEST',
      userName: customerInfo.name,
      date: new Date().toISOString(),
      items: cart,
      total: totalPrice + 30000,
      status: 'pending',
      paymentMethod: paymentMethod,
      address: customerInfo.address,
      phone: customerInfo.phone
    };

    setOrders([newOrder, ...orders]);
    
    if (user) {
        setAllUsers(prev => prev.map(u => 
            u.id === user.id 
            ? { ...u, orders: u.orders + 1, spent: u.spent + newOrder.total } 
            : u
        ));
        setUser(prev => ({ ...prev, orders: (prev.orders || 0) + 1, spent: (prev.spent || 0) + newOrder.total }));
    }

    setCart([]);
    alert(`Đặt hàng thành công! Mã đơn: ${newOrder.id}`);
    setView('home');
  };

  // --- Routing Logic ---

  if (view.startsWith('admin-')) {
    if (view === 'admin-products') return <AdminProducts />;
    if (view === 'admin-orders') return <AdminOrders />;
    if (view === 'admin-users') return <AdminUsers />;
    if (view === 'admin-stats') return <AdminStats />;
    return <AdminStats />;
  }

  return (
    <div className="min-h-screen bg-gray-50 font-sans text-gray-900 pb-20 md:pb-0">
      <Navbar />
      <main className="transition-opacity duration-300 ease-in-out">
        {view === 'home' && <HomeView />}
        {view === 'detail' && selectedProduct && <ProductDetailView />}
        {view === 'cart' && <CartView />}
        {view === 'pay' && <PaymentView />}
        {view === 'user' && user && <UserInfoView />}
      </main>
      <footer className="bg-white border-t mt-12 py-8"><div className="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm"><p>&copy; 2025 SneakerStore.</p></div></footer>
    </div>
  );
}