import react, { useState } from "react";

export default function AdminStats() {
  retrun(
    <AdminLayout>
      <h2 className="text-2xl font-bold mb-6">Thống kê</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded shadow-sm border">
          <div className="text-gray-500">Doanh thu</div>
          <div className="text-2xl font-bold">
            {orders.reduce((a, c) => a + c.total, 0).toLocaleString()} đ
          </div>
        </div>
        <div className="bg-white p-6 rounded shadow-sm border">
          <div className="text-gray-500">Đơn hàng</div>
          <div className="text-2xl font-bold">{orders.length}</div>
        </div>
        <div className="bg-white p-6 rounded shadow-sm border">
          <div className="text-gray-500">Sản phẩm</div>
          <div className="text-2xl font-bold">{products.length}</div>
        </div>
        <div className="bg-white p-6 rounded shadow-sm border">
          <div className="text-gray-500">User</div>
          <div className="text-2xl font-bold">{allUsers.length}</div>
        </div>
      </div>
    </AdminLayout>
  );
}
